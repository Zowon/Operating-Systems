#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>

#define PORT 8080 // Define the port number for the connection

// Function to handle receiving messages from the server
void *receive_messages(void *arg)
{
    int socket_fd = *(int *)arg; // Cast the argument to an integer (socket descriptor)
    char buffer[1024];           // Buffer to store received messages

    while (1)
    {
        memset(buffer, 0, sizeof(buffer));                               // Clear the buffer
        int bytes_received = recv(socket_fd, buffer, sizeof(buffer), 0); // Receive message from the server
        if (bytes_received <= 0)
        { // Check if the connection is lost
            printf("Disconnected from server.\n");
            pthread_exit(NULL); // Exit the thread if disconnected
        }
        printf("Server: %s\n", buffer); // Print the message from the server
    }
}

int main()
{
    int socket_fd;                     // Socket file descriptor
    struct sockaddr_in server_address; // Structure to hold server address details
    char message[1024];                // Buffer to hold messages to send

    // Create a socket
    if ((socket_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Socket failed"); // Print error if socket creation fails
        exit(EXIT_FAILURE);      // Exit the program
    }

    // Configure the server address
    server_address.sin_family = AF_INET;   // Use IPv4
    server_address.sin_port = htons(PORT); // Set the port number in network byte order

    // Convert IP address from text to binary form
    if (inet_pton(AF_INET, "127.0.0.1", &server_address.sin_addr) <= 0)
    {
        perror("Invalid address"); // Print error if address conversion fails
        exit(EXIT_FAILURE);        // Exit the program
    }

    // Connect to the server
    if (connect(socket_fd, (struct sockaddr *)&server_address, sizeof(server_address)) < 0)
    {
        perror("Connection failed"); // Print error if connection fails
        exit(EXIT_FAILURE);          // Exit the program
    }

    printf("Connected to the server. Type 'exit' to disconnect.\n");

    // Create a thread to handle receiving messages from the server
    pthread_t thread_id;
    if (pthread_create(&thread_id, NULL, receive_messages, (void *)&socket_fd) != 0)
    {
        perror("Thread creation failed"); // Print error if thread creation fails
        return -1;
    }

    // Main loop to send messages to the server
    while (1)
    {
        memset(message, 0, sizeof(message)); // Clear the message buffer
        printf("You: ");
        fgets(message, sizeof(message), stdin); // Read input from the user
        message[strcspn(message, "\n")] = 0;    // Remove the newline character

        // Check if the user wants to disconnect
        if (strcmp(message, "exit") == 0)
        {
            printf("Disconnecting...\n");
            break; // Exit the loop
        }

        // Send the message to the server
        send(socket_fd, message, strlen(message), 0);
    }

    // Close the socket
    close(socket_fd);
    return 0;
}
