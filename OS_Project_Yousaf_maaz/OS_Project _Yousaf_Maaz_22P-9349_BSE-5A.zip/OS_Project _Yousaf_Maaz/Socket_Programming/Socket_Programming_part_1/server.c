#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>

// Define the server port number
#define PORT 8080

// Define the maximum number of clients that can connect
#define MAX_CLIENTS 10

// Array to store client sockets
int client_sockets[MAX_CLIENTS];
int client_count = 0;

// Mutex to synchronize access to shared resources
pthread_mutex_t lock;

// Function to handle communication with a client
void *handle_client(void *arg)
{
    int client_socket = *(int *)arg; // Retrieve the client socket passed as an argument
    char buffer[1024];               // Buffer to store messages from the client

    while (1)
    {
        // Clear the buffer before receiving a new message
        memset(buffer, 0, sizeof(buffer));

        // Receive a message from the client
        int bytes_received = recv(client_socket, buffer, sizeof(buffer), 0);
        if (bytes_received <= 0)
        {
            // If no bytes are received, the client has disconnected
            printf("Client disconnected.\n");
            close(client_socket); // Close the client socket
            pthread_exit(NULL);   // Exit the thread
        }

        // Print the received message to the server console
        printf("Received from client: %s\n", buffer);

        // Broadcast the received message to all other connected clients
        pthread_mutex_lock(&lock); // Lock the mutex before accessing shared resources
        for (int i = 0; i < client_count; i++)
        {
            if (client_sockets[i] != client_socket)
            {
                // Send the message to all clients except the sender
                send(client_sockets[i], buffer, strlen(buffer), 0);
            }
        }
        pthread_mutex_unlock(&lock); // Unlock the mutex after broadcasting
    }
}

int main()
{
    int server_fd, new_socket;     // Server socket and client socket
    struct sockaddr_in address;    // Structure to hold server address details
    int addrlen = sizeof(address); // Size of the address structure

    // Initialize the mutex for synchronizing shared resources
    pthread_mutex_init(&lock, NULL);

    // Create the server socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("Socket creation failed"); // Print error if socket creation fails
        exit(EXIT_FAILURE);
    }

    // Define server address properties
    address.sin_family = AF_INET;         // Use IPv4
    address.sin_addr.s_addr = INADDR_ANY; // Accept connections from any IP address
    address.sin_port = htons(PORT);       // Convert port number to network byte order

    // Bind the socket to the specified IP and port
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0)
    {
        perror("Bind failed"); // Print error if binding fails
        exit(EXIT_FAILURE);
    }

    // Start listening for incoming connections
    if (listen(server_fd, MAX_CLIENTS) < 0)
    {
        perror("Listen failed"); // Print error if listening fails
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on port %d\n", PORT);

    while (1)
    {
        // Accept a new client connection
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen)) < 0)
        {
            perror("Accept failed"); // Print error if accepting a connection fails
            continue;                // Skip to the next iteration to handle other clients
        }

        printf("New client connected.\n");

        // Add the new client socket to the client sockets array
        pthread_mutex_lock(&lock); // Lock the mutex before modifying the array
        client_sockets[client_count++] = new_socket;
        pthread_mutex_unlock(&lock); // Unlock the mutex after modification

        // Create a new thread to handle communication with this client
        pthread_t thread_id;
        if (pthread_create(&thread_id, NULL, handle_client, (void *)&new_socket) != 0)
        {
            perror("Thread creation failed"); // Print error if thread creation fails
        }
    }

    // Clean up resources
    pthread_mutex_destroy(&lock); // Destroy the mutex
    close(server_fd);             // Close the server socket

    return 0;
}
